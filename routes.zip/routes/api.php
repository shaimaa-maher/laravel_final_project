<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/student', function (Request $request) {
    return $request->user();
});
Route::post('register', 'AuthController@register');
Route::post('login', 'AuthController@login');
Route::get('logout', 'AuthController@logout');
Route::get('student', 'AuthController@getAuthStudent');

Route::post('courses/{id}/comment', 'AuthController@comment')->name('Student.comment');
Route::post('courses/{id}/enroll', 'AuthController@enroll')->name('Student.enroll');
Route::get('courses/{id}/show', 'AuthController@show')->name('Student.show');

Route::put('student/update/{id}', 'AuthController@update')->name('Student.update');
