<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Comment;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Course;
use Illuminate\Http\Request;
use App\Http\Requests\AuthValidateRequest;
use App\Student;


class AuthController extends Controller
{
  
    public $loginAfterSignUp = true;

    public function register(Request $request)
    {
      $student = Student::create([
        'name' => $request->name,
        'email' => $request->email,
        'gender' => $request->gender,
        'profile_image' => $request->profile_image,
        'birth_date' => $request->birth_date,
        'password' => bcrypt($request->password),
        'password_confirmation' => bcrypt($request->password_confirmation),

      ]);

      $token = auth()->login($student);

      return $this->respondWithToken($token);
    }

    public function login(Request $request)
    {
      $credentials = $request->only(['email', 'password']);

      if (!$token = auth()->attempt($credentials)) {
        return response()->json(['error' => 'Unauthorized'], 401);
      }

      return $this->respondWithToken($token);
    }
    public function getAuthStudent(Request $request)
    {
        return response()->json(auth()->user());
    }
    public function logout()
    {
        auth()->logout();
        return response()->json(['message'=>'Successfully logged out']);
    }
    protected function respondWithToken($token)
    {  
      return response()->json([
        'access_token' => $token,
        'token_type' => 'bearer',
        'expires_in' => auth()->factory()->getTTL() * 60
      ]);
    }

function update(AuthValidateRequest $request ,$id){
 

  $students=Student::find($id);
  $students-> email = $request->input('email');
  $students-> gender = $request->input('gender');
  $students-> profile_image = $request->input('profile_image');
  $students-> birth_date = $request->input('birth_date');
  $students-> password = $request->input('password');
$students->save();
return response()->json($students);

}
public function comment(Request $request , Course $courses)

{
  $comments = Comment::create([
    'body' => $request->body,
    'student_id' => $request->student_id,
    'course_id' => $request->course_id,
    'supporter_id' => $request->supporter_id
  ]);


  return response()->json($comments);


}
public function enroll(Request $request , Course $courses)
{
  $courses = course::create([
  
    'name' => $request->name,
    'price' => $request->price,
    'cover_img' => $request->cover_img,
    'start_date' => $request->start_date,
    'end_date' => $request->end_date,
    'teacher_id' => $request->teacher_id,
    ]);
    $courses->save();
  return response()->json($courses);

}
public function show(Request $request , Course $courses)
{
  $courses = DB::table('courses')
            ->join('users', 'courses.teacher_id', '=', 'users.teacher_id')
            ->join('students', 'courses.student_id', '=', 'students.student_id')
            ->select('courses.price', 'courses.name','students.name')
            ->get();

}
}

