<html>

<head>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>

<body>
    <div class="container register">
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <h3 class="register-heading">Student Register</h3>
                <div class="row register-form">
                    <div class="col-md-6">
                    <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>


                        <form enctype="multipart/form-data" action="<?php echo route('profileavatar'); ?>" method="post">

                            <?php echo csrf_field(); ?>

                            <div class="form-group">

                                <input type="file" name="avater" class="form_control">

                                <input type="hidden" class="form-control" name="_token" placeholder="Password *" value="<?php echo e(csrf_token()); ?>" />



                            </div>

                            <button class="btn btn-primary-light" type="submit">upload picture</button>

                        </form>

                        <div class="form-group">
                            <input type="text" class="form-control" placeholder=" Name *" value="" />
                        </div>
                        
                            
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Password *" value="" />
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Confirm Password *" value="" />
                        </div>
                        <div class="form-group">

                            <input type="text" class="form-control" placeholder="year-day-month*" value="" />

                        </div>

                        <div class="form-group">
                            <div class="maxl">
                                <label class="radio inline">
                                    <input type="radio" name="gender" value="male" checked>
                                    <span> Male </span>
                                </label>
                                <label class="radio inline">
                                    <input type="radio" name="gender" value="female">
                                    <span>Female </span>
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Your Email *" value="" />
                            </div>
                            <input type="submit" class="btnRegister" value="Register" />
                        </div>
                    </div>
                </div>
            </div>

</div>
</form>
    
</body>

</html><?php /**PATH /home/sarah/Desktop/laravel_pro/resources/views/auth/student_register.blade.php ENDPATH**/ ?>